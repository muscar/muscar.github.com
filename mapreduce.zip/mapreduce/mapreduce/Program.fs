﻿module MapReduce

open System
open System.Diagnostics
open System.IO
open System.Net
open System.Net.Sockets
open System.Runtime.Serialization.Formatters.Binary
open System.Threading

type Agent<'T> = MailboxProcessor<'T> 

let ($) f x = f x

let serialize stream x = 
    let formatter = new BinaryFormatter()
    formatter.Serialize(stream, box x)

let deserialize stream = 
    let formatter = new BinaryFormatter()
    let res = formatter.Deserialize(stream)
    unbox res

module NetworkStreamExtensions =
    type System.Net.Sockets.NetworkStream with
        member this.AsyncWriteSerialized(data) =
            async { use buf = new MemoryStream()
                    serialize buf data
                    do! this.AsyncWrite(buf.ToArray()) }

open NetworkStreamExtensions

type MapReduceImpl =
    { map: string -> string -> seq<string * int>;
      reduce: string -> seq<int> -> int;
      combiner: string -> seq<int> -> int }

type WorkerRecord = 
    { id: int;
      stream: NetworkStream }

type MapReduceMsg = 
    | Map of string * string
    | Reduce of string * int list
and MapReduceMasterMsg = 
    | MapPair of string * int
    | ReducePair of string * int
    | MapDone

let stopwatch = new Stopwatch()

type Master(splits, m, r) = 
    // The master will act as a server, listening for incoming connections
    // from the workers, which it will categorize into mappers and reducers.
    let socket = new TcpListener(IPAddress.Any, 10003)

    let mappers = Array.create m { id = -1; stream = null }
    let reducers = Array.create r { id = -1; stream = null }

    let selectReducer k = reducers.[(abs $ k.GetHashCode()) % r]

    let actor = new Agent<MapReduceMasterMsg>(fun inbox ->
        let rec loop cnt s = 
            async { let! msg = inbox.Receive()
                    match msg with
                    | MapPair (k, v) -> return! loop cnt $ (k, v)::s
                    | MapDone -> 
//                        printfn "map done (%d more to go)" cnt
                        if cnt = 0 then
                            let aux = ref 0
                            for (k, v) in Seq.groupBy fst s do
                                let worker = selectReducer k
                                aux := !aux + 1
//                                printfn "sending entity to reducer"
                                do! worker.stream.AsyncWriteSerialized $ Reduce (k, Seq.map snd v |> List.ofSeq)
                            return! loop !aux []
                        else return! loop (cnt - 1) s
                    | ReducePair (k, r) -> 
                        let cnt'= cnt - 1
                        if cnt' = 0 then 
                            stopwatch.Stop()
                            printfn "%d ms" stopwatch.ElapsedMilliseconds
                            use f = new StreamWriter("out.txt")
                            for (w, c) in Seq.sortBy fst s do
                                f.WriteLine(sprintf "%s: %d" w c)
                            return ()
                        else return! loop cnt' $ (k, r)::s }
        loop (m - 1) [])

    let splitWork () = 
        stopwatch.Start()
        for split in splits do
            for (item, mapper) in Seq.zip split mappers do
                Async.Start(mapper.stream.AsyncWriteSerialized $ Map item)

    let rec asyncServiceClient (client: TcpClient) = 
        async { try
                    use stream = client.GetStream()
                    let msg: MapReduceMasterMsg = deserialize stream//ms
                    actor.Post(msg)
                    return! asyncServiceClient client
                with e ->
                    printfn "%s\n%s" e.Message e.StackTrace
                    return () }
                
    let rec serverLoop = function
        | (0, 0, doSplit) -> 
            if doSplit then splitWork ()
            Thread.Sleep(Timeout.Infinite)
        | (0, r, doSplit) -> 
            let client = socket.AcceptTcpClient()
            let id = client.GetStream().ReadByte()
            reducers.[r - 1] <- { id = id; stream = client.GetStream() }
            handleClient client
            serverLoop (0, r - 1, doSplit)
        | (m, r, doSplit) -> 
            let client = socket.AcceptTcpClient()
            let id = client.GetStream().ReadByte()
            mappers.[m - 1] <- { id = id; stream = client.GetStream() }
            handleClient client
            serverLoop (m - 1, r, doSplit)
    and handleClient client = Async.Start $ async {
        try 
            do! asyncServiceClient client 
        with e -> 
            printfn "%s\n%s" e.Message e.StackTrace
            return ()
    }

    let startServer () =
        socket.Start()
        let t = new Thread(ThreadStart(fun _ -> serverLoop (m, r, true)), IsBackground = true)
        t.Start()

    member this.Start() = 
        actor.Start()
        startServer ()

type Worker(address, port, id, impl) = 
    let master = new TcpClient()

    let actor = new Agent<MapReduceMsg>(fun inbox ->
        let mapAndGroup k v = 
            impl.map k v 
            |> Seq.groupBy fst 
            |> Seq.map (fun (k, vs) -> (k, Seq.map snd vs))

        let rec loop () = 
            async { let! msg = inbox.Receive()
                    match msg with
                    | Map (k, v) -> 
                        stopwatch.Stop()
                        stopwatch.Reset()
                        stopwatch.Start()
                        let r = mapAndGroup k v |> Seq.map (fun (k, vs) -> (k, impl.combiner k vs))
                                                |> List.ofSeq
                        stopwatch.Stop()
                        printfn "%d ms" stopwatch.ElapsedMilliseconds
                        for p in r do
                            do! master.GetStream().AsyncWriteSerialized $ MapPair p
                        do! master.GetStream().AsyncWriteSerialized MapDone
                    | Reduce (k, vs) -> 
                        //printf "%A: %A" k vs
                        let r = impl.reduce k $ Seq.ofList vs
                        do! master.GetStream().AsyncWriteSerialized $ ReducePair (k, r)
                    return! loop () }
        loop ())

    let rec asyncServiceClient (client: TcpClient) = 
        async { try
                    use stream = client.GetStream()
                    let msg: MapReduceMsg = deserialize stream
                    actor.Post(msg)
                    return! asyncServiceClient client
                with e ->
                    printfn "%s\n%s" e.Message e.StackTrace
                    return () }

    let connectClient (address: string) (port: int) =
        master.Connect(address, port)
        let t = new Thread(ThreadStart(fun _ -> Async.Start $ async {
            try
                master.GetStream().WriteByte(byte id)
                do! asyncServiceClient master
            with e -> 
                printfn "%s\n%s" e.Message e.StackTrace
                return ()
        }), IsBackground = true)
        t.Start()

    member this.Start() = 
        connectClient address port
        actor.Start()

let splitInput m l =
    let psize = List.length l / m
    let rec aux = function
        | ([] as l, _, acc) | (l, 0, acc) -> (acc, l)
        | (h::t, n, acc) -> aux (t, n - 1, h::acc)
    let rec loop = function
        | [] -> []
        | l -> let (l, r) = aux (l, m, []) in l :: loop r
    loop l

let mapreduce input m r =
    let splits = splitInput m input
    let master = new Master(splits, m, r)
    master.Start()

let parseArgs args = 
    args
    |> Array.map (fun (a: string) -> a.Split([|'='; ' '|], StringSplitOptions.RemoveEmptyEntries))
    |> Array.map (function [|k; v|] -> (k, v) | _ -> failwith "bad arguments")
    |> Map.ofArray

let argValue arg argMap = 
    match Map.tryFind arg argMap with
    | Some v -> v
    | _ -> failwith $ sprintf "expected argument `%s` not found" arg

let counterImpl = 
//    let seps = [|' '; '\t'; '\r'; '\n'; ';'; '.'; ','; '?'; '!'; '-'; '('; ')'; '\''; '"'|]
    let seps = [|' '; '\t'; '\r'; '\n'|]
    { map = fun name path ->
        let file = new StreamReader(path)
        seq { for w in file.ReadToEnd().Split(seps, StringSplitOptions.RemoveEmptyEntries) ->
                (w, 1) };
      reduce = fun word counts -> Seq.reduce (+) counts;
      combiner = fun word counts -> Seq.reduce (+) counts }

let input = [("republic", "republic.txt"); ("ethics", "ethics.txt"); ("problems of philosophy", "pop.txt"); ("Sidartha", "sidartha.txt")]

[<EntryPoint>]
let main args = 
    let argMap = parseArgs args
    if Map.containsKey "id" argMap then
        let id = argValue "id" argMap
        let address = argValue "address" argMap
        let port = argValue "port" argMap
        let worker = new Worker(address, int port, int id, counterImpl)
        worker.Start()
    else
        let mappers = argValue "mappers" argMap
        let reducers = argValue "reducers" argMap
        mapreduce input (int mappers) (int reducers)
    Console.ReadKey() |> ignore
    0