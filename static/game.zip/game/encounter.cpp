#include "encounter.h"

Encounter::Encounter(int count)
{
    for (int i = 0; i < count; ++i)
    {
        int monster_type = rand_int(0, 2);
        switch (monster_type)
        {
            case 0:
                monsters_.push_back(new Goblin());
                break;
            case 1:
                monsters_.push_back(new Orc());
                break;
            case 2:
                monsters_.push_back(new Bugbear());
                break;
        }
    }
}

std::tuple<int, int> Encounter::attack(Player *p, int idx)
{
    if (idx < 0 || idx >= monsters_.size())
    {
        return std::make_tuple(0, 0);
    }

    int player_damage = p->attack(monsters_[idx]);
    int monsters_damage = 0;

    if (!monsters_[idx]->is_alive())
    {
        remove_monster(idx);
    }

    for (int i = 0; i < monsters_.size(); ++i)
    {
        monsters_damage += monsters_[idx]->attack(p);
    }

    return std::make_tuple(player_damage, monsters_damage);
}

bool Encounter::is_over() const
{
    return monsters_.size() == 0;
}

void Encounter::print(std::ostream &stream) const
{
    for (int i = 0; i < monsters_.size(); ++i)
    {
        stream << i + 1 << ".) " << *monsters_[i] << std::endl;
    }
}

void Encounter::remove_monster(int idx)
{
    monsters_.erase(monsters_.begin() + idx);
}

std::ostream &operator<<(std::ostream &stream, const Encounter &encounter)
{
    encounter.print(stream);
    return stream;
}
