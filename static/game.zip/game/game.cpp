#include <iostream>
#include <tuple>
#include <cstdlib>
#include <ctime>

#include "creature.h"
#include "player.h"
#include "encounter.h"

#include "utils.h"

void game_loop()
{
    Player p("Courage");
    Encounter e(3);

    do
    {
        std::cout << p << std::endl;
        std::cout << e << std::endl;

        int idx = 0;
        std::cout << "Which monster do you want to attack? ";
        std::cin >> idx;

        std::tuple<int, int> attacks = e.attack(&p, idx - 1);
        std::cout << "The player deals " << std::get<0>(attacks) << " damage" << std::endl;
        std::cout << "The monsters deal " << std::get<1>(attacks) << " damage" << std::endl;

        std::cout << "== Next turn ==" << std::endl;
    }
    while (p.is_alive() && !e.is_over());

    if (p.is_alive())
    {
        std::cout << "You win. Take the loot and run!" << std::endl;
    }
    else
    {
        std::cout << "You're dead. It's gotta hurt." << std::endl;
    }
}

int main(int argc, char const *argv[])
{
    std::srand(std::time(NULL));
    game_loop();

    return 0;
}
