#include "creature.h"

int Creature::attack(Creature *other) const
{
    int dealt_damage = rand_int(0, damage_);
    other->health_ -= dealt_damage;
    return dealt_damage;
}

bool Creature::is_alive() const
{
    return health_ > 0;
}

void Creature::print(std::ostream &stream) const
{
    stream << describe() << " "
           << "HP: " << health_ << "; "
           << "DMG: " << damage_;
}

std::ostream &operator<<(std::ostream &stream, const Creature &creature)
{
    creature.print(stream);
    return stream;
}
