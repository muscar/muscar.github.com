#include "utils.h"

int rand_int(int min, int max)
{
    return min + (std::rand() % (max - min + 1));
}
