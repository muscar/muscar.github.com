#ifndef __ENCOUNTER_H__
#define __ENCOUNTER_H__

#include <iostream>
#include <vector>
#include <tuple>

#include "player.h"

#include "monsters/goblin.h"
#include "monsters/orc.h"
#include "monsters/bugbear.h"

class Encounter
{
public:
    Encounter(int count);

    std::tuple<int, int> attack(Player *p, int idx);

    bool is_over() const;

    void print(std::ostream &stream) const;

private:
    std::vector<Creature *> monsters_;

    void remove_monster(int idx);
};

std::ostream &operator<<(std::ostream &stream, const Encounter &encounter);

#endif
