#ifndef __CREATURE_H__
#define __CREATURE_H__

#include <iostream>

#include "utils.h"

class Creature
{
public:
    int attack(Creature *other) const;

    bool is_alive() const;

    void print(std::ostream &stream) const;

protected:
    Creature(int health, int damage)
    : health_(health), damage_(damage)
    {
    }

    virtual std::string describe() const = 0;

private:
    int health_;
    int damage_;
};

std::ostream &operator<<(std::ostream &stream, const Creature &creature);

#endif
