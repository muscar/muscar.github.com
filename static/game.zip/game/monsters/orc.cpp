#include "orc.h"

std::string Orc::describe() const
{
    return "Orc";
}
