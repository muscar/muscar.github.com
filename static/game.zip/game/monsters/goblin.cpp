#include "goblin.h"

std::string Goblin::describe() const
{
    return "Goblin";
}
