#include "bugbear.h"

std::string Bugbear::describe() const
{
    return "Bugbear";
}
