#ifndef __ORC_H__
#define __ORC_H__

#include <iostream>

#include "../creature.h"

class Orc : public Creature
{
public:
    Orc()
    : Creature(6, 4)
    {
    }

private:
    std::string describe() const;
};

#endif
