#ifndef __GOBLIN_H__
#define __GOBLIN_H__

#include <iostream>

#include "../creature.h"

class Goblin : public Creature
{
public:
    Goblin()
    : Creature(3, 1)
    {
    }

private:
    std::string describe() const;
};

#endif
