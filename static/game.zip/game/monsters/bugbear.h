#ifndef __BUGBEAR_H__
#define __BUGBEAR_H__

#include <iostream>

#include "../creature.h"

class Bugbear : public Creature
{
public:
    Bugbear()
    : Creature(10, 6)
    {
    }

private:
    std::string describe() const;
};

#endif
