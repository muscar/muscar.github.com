#include "player.h"

std::string Player::describe() const
{
    return name_;
}
