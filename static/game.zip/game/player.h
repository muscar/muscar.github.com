#ifndef __PLAYER_H__
#define __PLAYER_H__

#include "creature.h"

class Player : public Creature
{
public:
    Player(std::string name)
    : Creature(13, 5), name_(name)
    {
    }

private:
    std::string name_;

    std::string describe() const;
};

#endif
