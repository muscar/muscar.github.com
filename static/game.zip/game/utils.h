#ifndef __UTILS_H__
#define __UTILS_H__

#include <cstdlib>

int rand_int(int min, int max);

#endif