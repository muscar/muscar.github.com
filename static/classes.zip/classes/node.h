#ifndef __NODE_H__
#define __NODE_H__

#include <stdlib.h>

class node_t
{
    int value_;
    node_t *next_;

public:
    node_t(int value = 0, node_t *next = NULL) : value_(value), next_(next) { }

    int get_value() const;

    node_t *get_next() const;

    void set_next(node_t *next);
};

#endif
