#include <stdio.h>
#include <stdlib.h>

#include "list.h"

int main(int argc, char const *argv[])
{
    int value = 0;

    list_t *root = new list_t();
    root->insert_beginning(1);
    root->insert_beginning(2);
    root->insert_beginning(3);
    root->insert_beginning(4);
    root->insert_beginning(5);
    
    while (root->remove_beginning(value))
    {
        printf("%d\n", value);
    }

    return 0;
}
