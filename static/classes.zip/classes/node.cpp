#include "node.h"

int node_t::get_value() const
{
    return this->value_;
}

node_t *node_t::get_next() const
{
    return this->next_;
}

void node_t::set_next(node_t *next)
{
    this->next_ = next;
}
