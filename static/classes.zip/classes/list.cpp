#include "list.h"

list_t::list_t()
{
    this->first_ = NULL;
    this->length_ = 0;
}

list_t::~list_t()
{
    if (this->first_ != NULL)
    {
        delete this->first_;
    }
}

size_t list_t::get_length() const
{
    return this->length_;
}

void list_t::insert_beginning(int value)
{
    node_t *new_node = new node_t(value);
    new_node->set_next(this->first_);
    this->first_ = new_node;
    this->length_++;
}

bool list_t::remove_beginning(int &value)
{
    node_t *aux = this->first_;

    if (aux == NULL)
    {
        return false;
    }

    this->first_ = aux->get_next();
    this->length_--;
    value = aux->get_value();
    delete aux;

    return true;
}
