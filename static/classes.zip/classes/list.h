#ifndef __LIST_H__
#define __LIST_H__

#include <stdlib.h>

#include "node.h"

class list_t
{
    node_t *first_;
    size_t length_;

public:
    list_t();

    size_t get_length() const;

    void insert_beginning(int value);

    bool remove_beginning(int &value);
};

#endif
