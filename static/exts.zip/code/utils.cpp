#include "utils.hpp"

int inc(int value, int delta)
{
    return value + delta;
}
