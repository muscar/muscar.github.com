#include <iostream>
#include "utils.hpp"

// Template function

template<typename T>
bool find_min(const T v[], size_t len, T &result)
{
    // Check the length of the array
    if (len < 1)
    {
        return false;
    }

    // Assume the first element is the smallest...
    result = v[0];
    
    // ... 'till we're proven wrong
    for (int i = 1; i < len; ++i)
    {
        result = min(result, v[i]);
    }

    return true;
}

// Function overloading

int cmp(int m, int n)
{
    if (m == n)
    {
        return 0;
    }
    return m < n ? -1 : 1;
}

int cmp(std::string m, std::string n)
{
    if (m == n)
    {
        return 0;
    }
    return m < n ? -1 : 1;
}

int main(int argc, char *argv[])
{
    int m = 1, n = 2;

    std::cout << "m = " << m << ", n = " << n << std::endl;
    swap(m, n);
    std::cout << "m = " << m << ", n = " << n << std::endl;

    std::cout << min(0, 1) << std::endl;
    std::cout << max(0, 1) << std::endl;
    std::cout << inc(1) << std::endl;
    std::cout << inc(1, 2) << std::endl;

    std::cout << min('a', 'b') << std::endl;
    std::cout << max('a', 'b') << std::endl;

    std::cout << "===" << std::endl;

    std::cout << "count? ";
    std::cin >> n;

    int *a = new int[n];

    for (int i = 0; i < n; ++i)
    {
        std::cout << "n = ";
        std::cin >> a[i];
    }

    if (find_min(a, n, m))
    {
        std::cout << m << std::endl;;
    }
    else
    {
        std::cout << "empty array" << std::endl;
    }

    delete a;

    std::cout << "===" << std::endl;

    std::cout << cmp(1, 2) << std::endl;
    std::cout << cmp("xyz", "abc") << std::endl;

    return 0;
}
