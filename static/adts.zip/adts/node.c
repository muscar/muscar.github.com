#include "node.h"

node_t *node_empty()
{
    return (node_t *) malloc(sizeof(node_t));
}

node_t *node_make(int value, node_t *next)
{
    node_t *node = node_empty();
    node->value = value;
    node->next = next;
    return node;
}

node_t *node_singleton(int value)
{
    return node_make(value, NULL);
}
