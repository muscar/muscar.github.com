#include "node.h"

struct node_t *node_empty()
{
    return (struct node_t *) malloc(sizeof(struct node_t));
}

struct node_t *node_make(int value, struct node_t *next)
{
    struct node_t *node = node_empty();
    node->value = value;
    node->next = next;
    return node;
}

struct node_t *node_singleton(int value)
{
    return node_make(value, NULL);
}
