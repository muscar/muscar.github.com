#include "list.h"

struct list_t *list_empty()
{
    struct list_t *list = (struct list_t *) malloc(sizeof(struct list_t));
    list->first = 0;
    list->length = 0;
    return list;
}

size_t list_length(struct list_t *list)
{
    return list->length;
}

void list_insert_beginning(struct list_t *list, int value)
{
    node_t *new_node = node_singleton(value);
    new_node->next = list->first;
    list->first = new_node;
    list->length++;
}

unsigned char list_remove_beginning(struct list_t *list, int *value)
{
    node_t *aux = list->first;

    if (aux == 0)
    {
        return 0;
    }

    list->first = aux->next;
    list->length--;
    *value = aux->value;
    free(aux);

    return 1;
}
