#include "list.h"

list_t *list_empty()
{
    list_t *list = (list_t *) malloc(sizeof(list_t));

    if (list != NULL)
    {
        list->first = 0;
        list->length = 0;
    }

    return list;
}

size_t list_length(list_t *list)
{
    return list->length;
}

void list_insert_beginning(list_t *list, int value)
{
    node_t *new_node = node_singleton(value);
    new_node->next = list->first;
    list->first = new_node;
    list->length++;
}

unsigned char list_remove_beginning(list_t *list, int *value)
{
    node_t *aux = list->first;

    if (aux == NULL)
    {
        return 0;
    }

    list->first = aux->next;
    list->length--;
    *value = aux->value;
    free(aux);

    return 1;
}
