#ifndef __VECTOR_H__
#define __VECTOR_H__

#include <stdlib.h>
#include <string.h>

struct vector_t
{
    int *data;
    size_t length;
    size_t capacity;
};

struct vector_t *vector_make(size_t capacity);

size_t vector_length(struct vector_t *vector);

void vector_push(struct vector_t *vector, int value);

unsigned char vector_pop(struct vector_t *vector, int *value);

#endif
