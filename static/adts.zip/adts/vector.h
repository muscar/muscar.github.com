#ifndef __VECTOR_H__
#define __VECTOR_H__

#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef struct _vector_t
{
    int *data;
    size_t length;
    size_t capacity;
} vector_t;

vector_t *vector_make(size_t capacity);

size_t vector_length(vector_t *vector);

void vector_push(vector_t *vector, int value);

bool vector_pop(vector_t *vector, int *value);

#endif
