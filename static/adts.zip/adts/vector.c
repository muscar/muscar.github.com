#include "vector.h"

vector_t *vector_make(size_t capacity)
{
    vector_t *vector = (vector_t *) malloc(sizeof(vector_t));
    vector->data = (int *) malloc(capacity * sizeof(int));
    vector->length = 0;
    vector->capacity = capacity;
    return vector;
}

size_t vector_length(vector_t *vector)
{
    return vector->length;
}

void vector_resize(vector_t *vector, size_t new_capcity)
{
    int *new_data = (int *) realloc(vector->data, new_capcity * sizeof(int));
    vector->data = new_data;
    vector->capacity = new_capcity;
}

void vector_push(vector_t *vector, int value)
{
    if (vector->length >= vector->capacity)
    {
        vector_resize(vector, vector->capacity * 2);
    }
    vector->data[vector->length++] = value;
}

unsigned char vector_pop(vector_t *vector, int *value)
{
    size_t new_length = 0;

    if (vector->length <= 0)
    {
        return 0;
    }

    new_length = vector->length - 1;
    vector->length = new_length;
    *value = vector->data[new_length];

    return 1;
}
