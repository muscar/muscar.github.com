#ifndef __NODE_H__
#define __NODE_H__

#include <stdlib.h>

struct node_t
{
    int value;
    struct node_t *next;
};

struct node_t *node_empty();

struct node_t *node_make(int value, struct node_t *next);

struct node_t *node_singleton(int value);

#endif
