#ifndef __LIST_H__
#define __LIST_H__

#include <stdlib.h>

#include "node.h"

struct list_t
{
    struct node_t *first;
    size_t length;
};

struct list_t *list_empty();

size_t list_length(struct list_t *list);

void list_insert_beginning(struct list_t *list, int value);

unsigned char list_remove_beginning(struct list_t *list, int *value);

#endif
