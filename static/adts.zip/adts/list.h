#ifndef __LIST_H__
#define __LIST_H__

#include <stdlib.h>
#include <stdbool.h>

#include "node.h"

typedef struct _list_t
{
    node_t *first;
    size_t length;
} list_t;

list_t *list_empty();

size_t list_length(list_t *list);

void list_insert_beginning(list_t *list, int value);

bool list_remove_beginning(list_t *list, int *value);

#endif
