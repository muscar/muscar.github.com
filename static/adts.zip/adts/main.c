#include <stdio.h>
#include <stdlib.h>

#include "list.h"
#include "vector.h"

int main(int argc, char const *argv[])
{
    int i = 0, value = 0;
    vector_t *v;
    list_t *root;

    v = vector_make(2);
    for (i = 0; i < 32; ++i)
    {
        vector_push(v, i);
    }

    while (vector_pop(v, &value))
    {
        printf("%d\n", value);
    }

    printf("=====\n");

    root = list_empty();
    list_insert_beginning(root, 1);
    list_insert_beginning(root, 2);
    list_insert_beginning(root, 3);
    list_insert_beginning(root, 4);
    list_insert_beginning(root, 5);
    
    while (list_remove_beginning(root, &value))
    {
        printf("%d\n", value);
    }

    return 0;
}
