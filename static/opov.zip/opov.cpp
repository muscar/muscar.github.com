#include <iostream>
#include <fstream>

class Box
{
    int value_;
    
public:
    Box(int value = 0) : value_(value) { }

    Box &operator+=(const Box &b)
    {
        value_ += b.get_value();
        return *this;
    }

    Box &operator+=(int i)
    {
        value_ += i;
        return *this;
    }

    int get_value() const
    {
        return value_;
    }

    void set_value(int value)
    {
        value_ = value;
    }
};

Box operator+(Box b1, const Box &b2)
{
    b1 += b2;
    return b1;
}

std::istream &operator>>(std::istream &s, Box &b)
{
    int i;
    s >> i;
    b.set_value(i);
    return s;
}

std::fstream &operator>>(std::fstream &s, Box &b)
{
    int i;
    s >> i;
    b.set_value(i);
    return s;
}

std::ostream &operator<<(std::ostream &s, const Box &b)
{
    s << b.get_value();
    return s;
}

int main(int argc, char const *argv[])
{
    std::fstream fin("input", std::fstream::in);

    Box b1, b2;

    fin >> b1;

    std::cout << "b2 = ";
    std::cin >> b2;

    Box b3 = b1 + b2;

    b3 += 3;

    std::cout << b1 << std::endl;
    std::cout << b2 << std::endl;
    std::cout << b3 << std::endl;

    return 0;
}
