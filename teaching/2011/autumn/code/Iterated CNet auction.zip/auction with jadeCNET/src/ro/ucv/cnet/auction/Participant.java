package ro.ucv.cnet.auction;

import jade.core.Agent;
import jade.core.behaviours.Behaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.proto.SSResponderDispatcher;

@SuppressWarnings("serial")
public class Participant extends Agent {
	public void setup() {
		System.out.println(getLocalName() + " online");

		MessageTemplate tpl = MessageTemplate.MatchPerformative(ACLMessage.CFP);
		addBehaviour(new SSResponderDispatcher(this, tpl) {
			protected Behaviour createResponder(ACLMessage initiationMsg) {
				return new ParticipantBehaviour(myAgent, initiationMsg);
			}
		});
	}
}
