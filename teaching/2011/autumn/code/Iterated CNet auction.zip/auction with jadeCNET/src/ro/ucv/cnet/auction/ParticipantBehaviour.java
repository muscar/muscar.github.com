package ro.ucv.cnet.auction;

import jade.core.Agent;
import jade.domain.FIPAAgentManagement.FailureException;
import jade.lang.acl.ACLMessage;
import jade.proto.SSIteratedContractNetResponder;

@SuppressWarnings("serial")
public class ParticipantBehaviour extends SSIteratedContractNetResponder {
	public ParticipantBehaviour(Agent a, ACLMessage cfp) {
		super(a, cfp);
	}
	
	protected ACLMessage handleCfp(ACLMessage cfp) {
		System.out.println(myAgent.getLocalName() + ": received cfp "
				+ cfp.getContent());
		ACLMessage response = cfp.createReply();
		response.setPerformative(ACLMessage.PROPOSE);
		response.setContent(" suma licitata ");
		return response;
	}
	
	protected ACLMessage handleAcceptProposal(ACLMessage cfp,
			ACLMessage propose, ACLMessage accept) throws FailureException {
		System.out.println(myAgent.getLocalName() + ": am primit accept");
		// Conform FIPA castigatorul nu trimite un mesaj de raspuns
		return null;
	}
	
	protected void handleRejectProposal(ACLMessage cfp, ACLMessage propose,
			ACLMessage reject) {
		System.out.println(myAgent.getLocalName() + ": am primit reject");
	}
	
	@Override
	protected void handleOutOfSequence(ACLMessage msg) {
		System.out.println("participant " + myAgent.getLocalName()
				+ " received msg out of seq: " + msg.getContent());
	}

}
