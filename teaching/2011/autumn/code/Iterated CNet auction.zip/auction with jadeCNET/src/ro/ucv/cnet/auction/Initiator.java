package ro.ucv.cnet.auction;

import java.util.Date;
import jade.core.AID;
import jade.core.Agent;
import jade.lang.acl.ACLMessage;

@SuppressWarnings("serial")
public class Initiator extends Agent {
	public void startCNET(String s) {
		ACLMessage cfp = new ACLMessage(ACLMessage.CFP);
		cfp.setContent(s);
		cfp.setReplyByDate(new Date(System.currentTimeMillis() + 3000));
		
		for (Object arg : getArguments()) {
			cfp.addReceiver(new AID((String) arg, AID.ISLOCALNAME));
		}
		
		addBehaviour(new InitiatorBehaviour(this, cfp));
	}
	
	public void setup() {
		System.out.println(getLocalName() + " online");
		startCNET("initial proposal");
	}

}
