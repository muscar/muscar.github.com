package ro.ucv.cnet.auction;

import jade.core.Agent;
import jade.lang.acl.ACLMessage;
import jade.proto.ContractNetInitiator;

import java.util.Date;
import java.util.Vector;

@SuppressWarnings("serial")
public class InitiatorBehaviour extends ContractNetInitiator {
	private int count = 0;

	public InitiatorBehaviour(Agent a, ACLMessage cfp) {
		super(a, cfp);
	}
	
	protected void handlePropose(ACLMessage propose, Vector acceptances) {
		System.out.println(myAgent.getLocalName()
				+ ": am primit un propose de la "
				+ propose.getSender().getLocalName());
	}
	
	private boolean shouldStop() {
		return count > 2;
	}
	
	private Object pickWinner(Vector messages) {
		return messages.get((int) (Math.random() * messages.size()));
	}
	
	protected void handleAllResponses(Vector responses, Vector acceptances) {
		boolean finalStep = shouldStop();
		
		for (Object e : responses) {
			ACLMessage msg = ((ACLMessage) e).createReply();
			if (finalStep) {
				msg.setPerformative(ACLMessage.REJECT_PROPOSAL);
			} else {
				msg.setPerformative(ACLMessage.CFP);
				msg.setContent("step #" + count);
				msg.setReplyByDate(new Date(System.currentTimeMillis() + 3000));
			}
			acceptances.addElement(msg);
		}
		
		if (finalStep) {
			Object winner = pickWinner(acceptances);
			((ACLMessage) winner).setPerformative(ACLMessage.ACCEPT_PROPOSAL);
		} else {
			newIteration(acceptances);
			count++;
		}
	}

	protected void handleRefuse(ACLMessage refuse) {
		System.out.println(myAgent.getLocalName() + ":Agent "
				+ refuse.getSender().getName() + " refused");
	}
	
	protected void handleFailure(ACLMessage failure) {
		if (failure.getSender().equals(myAgent.getAMS())) {
			// FAILURE notification from the JADE runtime: the receiver
			// does not exist
			System.out.println(myAgent.getLocalName()
					+ ":Responder does not exist");
		} else {
			System.out.println(myAgent.getLocalName() + ":Agent "
					+ failure.getSender().getName() + " failed");
		}

	}
	
	@Override
	protected void handleOutOfSequence(ACLMessage msg) {
		System.out.println("initiator " + myAgent.getLocalName()
				+ "received msg out of seq: " + msg.getContent());
	}

}
