﻿module Monads

open Utils

// The backtracking monad

type Choice<'a> = Choice of seq<'a>

let choose xs = Choice xs

let mzero () = choose Seq.empty

let unLogic (Choice c) = c

let private join choices = 
    Choice (choices |> Seq.map unLogic 
                    |> Seq.concat
                    |> Seq.cache)

let observe c = c |> unLogic |> Seq.head

type LogicBuilder() = 
    member m.Return(x) = choose [x]
    member m.Bind(Choice m, f) = join $ Seq.map f m
    member m.Zero() = mzero ()
    member m.ReturnFrom(Choice m) = choose m
    member m.Combine(m1, m2) = join [m1; m2]
    member m.Delay(f) = f ()

let logic = new LogicBuilder()

// The BDI monad

type StateT<'s, 'a> = StateT of ('s -> (Choice<'a * 's>))

let getState () = StateT $ fun s -> logic.Return(s, s)

let setState x = StateT $ fun _ -> logic.Return((), x)

let private lift x = StateT $ fun s -> 
    logic { let! m = x
            return m, s }

let chooseL c = lift $ choose c

let private runStateT (StateT s) x = s x

let runBdi (StateT s) x = s x |> unLogic

let notM (StateT b) = StateT $ fun s ->
    let c = unLogic $ b s
    if not $ Seq.isEmpty c then choose [] else choose [(), s]

let (<&&>) c1 c2 = StateT $ fun s ->
    logic.Combine(runStateT c1 s, runStateT c2 s)

type StateTBuilder(l: LogicBuilder) = 
    member m.Return(x) = StateT $ fun s -> l.Return(x, s)
    member m.Bind(m', f) = StateT $ fun s ->
        logic { let! a, s' = runStateT m' s
                let! r = runStateT (f a) s'
                return r }
    member m.ReturnFrom(StateT m') = StateT $ fun s -> m' s
    member m.Zero() = StateT $ fun _ -> l.Zero()

let bdi = new StateTBuilder(logic)
