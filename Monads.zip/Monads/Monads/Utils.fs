﻿module Utils

let ($) f x = f x
