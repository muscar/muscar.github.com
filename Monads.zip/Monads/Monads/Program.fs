﻿open Utils
open Monads
open Edsl
open Visualizer

let applyContext p = 
    bdi { let! kb = getState ()
          if List.exists ((=) p) kb then
              return () }

//let withBeliefs b = 
//    bdi { do! setState beliefs
//          return! b }
//let withGoals b = 
//    bdi { do! setState goals
//          return! b }

let withContext c b = 
    bdi { do! setState c
          return! b }

let bel x = 
    not $ Seq.isEmpty (runBdi (withContext beliefs x) [])

let goal x = 
    not $ Seq.isEmpty (runBdi (withContext goals x) [])

let a_goal x = goal x && not $ bel x

let goal_a x = goal x && bel x

let on' (x, y) = applyContext $ on (x, y)

let getTop b = 
    bdi { let! x = chooseL blocks
          do! on' (x, b)
          return x }

let getBottom b = 
    bdi { let! x = chooseL (blocks @ [Table])
          do! on' (b, x)
          return x }

let clear x = 
    bdi { match x with
          | Table -> return ()
          | _ -> return! notM (getTop x) }
                 //return () }

let rec tower t = 
    bdi { match t with
          | [x] -> return! on' (x, Table)
          | x::y::t -> do! on' (x, y)
                       return! tower $ y::t }
          //| _ -> return () }

let rec genTower x =
    bdi { let! y = getBottom x
          match y with
          | Table -> return [x]
          | _ -> let! b = genTower y
                 return x::b }

let genTowers () = 
    bdi { let! x = chooseL blocks
          return! genTower x }

let move (x, y) =
    bdi { do! clear x <&&> clear y
          let! z = chooseL (blocks @ [Table])
          do! on' (x, z)
          if not (y = z) then
              return ([on (x, z)], [on (x, y)]) }

let actionRules t = 
    bdi { match t with
          | x::y::bs when a_goal (tower t) && bel $ tower (y::bs) -> return! move (x, y)
          | x::_ when a_goal (tower t) -> return! move (x, Table) 
          | _ -> () }

let step () = 
    bdi { let! t = withContext goals $ genTowers ()
          return! withContext beliefs $ actionRules t }

let run () = 
    while not $ List.forall (goal') beliefs do
        let (delList, addList) = fst (Seq.head (runBdi (withContext beliefs $ step ()) []))
        printfn "%A" addList
        beliefs <- List.filter (fun b -> not $ List.exists ((=) b) delList) beliefs

open System.Windows.Forms
open Visualizer

[<EntryPoint>]
let main args =
    let aux (f: CubeWorldVisualizerForm) = 
        let (delList, addList) = fst (Seq.head (runBdi (withContext beliefs $ step ()) []))
        match addList with
        | [Pred ("on", [c1; c2])] -> f.MoveCube(c1, c2)
        f.Invalidate()
        printfn "%A" addList
        beliefs <- List.filter (fun b -> not $ List.exists ((=) b) delList) beliefs
        beliefs <- beliefs @ addList
    let f = new CubeWorldVisualizerForm(width = 700, height = 400, step = aux)

    f.AddCube(C)
    f.AddCube(E)
    f.AddCube(G)
    f.AddCube(B, C)
    f.AddCube(D, E)
    f.AddCube(F, G)
    f.AddCube(A, B)

    Application.EnableVisualStyles()
    Application.Run(f)
    0