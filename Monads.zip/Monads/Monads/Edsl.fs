﻿module Edsl

open Utils
open Monads

// EDSL

type Pred<'T> = Pred of string * 'T list

let predicate name args = Pred (name, args)

type Obj = A | B | C | D | E | F | G | Table

let on (x, y) = Pred ("on", [x; y])

let blocks = [A; B; C; D; E; F; G]

let mutable beliefs = [ on (A, B); on (B, C); on (C, Table); on (D, E); on (E, Table); on (F, G); on (G, Table) ]
let mutable goals = [ on (A, E); on (B, Table); on (C, Table); on (D, C); on (E, B); on (F, D); on (G, Table) ]

let goal' p = List.exists ((=) p) goals
