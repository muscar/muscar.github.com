﻿module Visualizer

open System
open System.Collections.Generic
open System.Drawing
open System.Windows.Forms
open Utils
open Edsl

type CubeWorldVisualizer(width: int, height: int, cubeEdge: int) =
    let table = new List<List<Obj>>()
    
    member x.AddCube(cube, onTopOf) = 
        match onTopOf with
        | Some c -> match table.Find(fun l -> l.[0] = c) with
                    | null -> failwith $ sprintf "can't add %A on top of %A" cube c
                    | t -> t.Insert(0, cube)
        | _ -> table.Add(new System.Collections.Generic.List<Obj>([cube]))

    member x.MoveCube(cube, dest) =
        match table.Find(fun l -> l.[0] = cube) with
        | null -> failwith $ sprintf "can't move %A" cube
        | t -> 
            t.Remove(cube) |> ignore
            if t.Count = 0 then table.Remove(t) |> ignore
            match dest with
            | Table -> x.AddCube(cube, None)
            | _ -> x.AddCube(cube, Some dest)

    member x.Render(g: Graphics) = 
        g.Clear(Color.LightGray)
        use f = new Font("Segoe UI", 24.0f)
        let mutable x = 10
        for t in table do
            let mutable y = 250
            for i = t.Count - 1 downto 0 do
                g.FillRectangle(Brushes.LightBlue, x, y, cubeEdge, cubeEdge)
                g.DrawRectangle(Pens.Black, x, y, cubeEdge, cubeEdge)
                g.DrawString(sprintf "%A" t.[i], f, Brushes.Black, float32 x, float32 y)
                y <- y - cubeEdge
            x <- x + cubeEdge + 10

    member x.Done(g: Graphics) =
        use f = new Font("Segoe UI", 54.0f)
        let size = g.MeasureString("Done", f)
        g.FillRectangle(new SolidBrush(Color.FromArgb(85, Color.Black)), 0, 0, width, height)
        g.DrawString("Done", f, Brushes.WhiteSmoke, (float32 width - size.Width) / 2.0f, (float32 height - size.Height) / 2.0f)

type CubeWorldVisualizerForm(width, height, step) as this = 
    inherit Form(Text="Block World Agent", Width = width, Height = height)
    do this.SetStyle(ControlStyles.DoubleBuffer |||  ControlStyles.UserPaint ||| ControlStyles.AllPaintingInWmPaint, true)
    do this.UpdateStyles()

    let b = new Button(Text="Next move", Top=325, Left=600)
    let v = new CubeWorldVisualizer(this.ClientSize.Width, this.ClientSize.Height, 75)

    do b.Click.Add(fun _ -> step this)
    do this.Controls.Add(b)
    do this.Paint.Add(fun e -> v.Render(e.Graphics))

    member x.AddCube(c1, ?c2) = v.AddCube(c1, c2)
    member x.MoveCube = v.MoveCube
